<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PER_Peg_Controller extends MY_Controller {

  function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('default', true);
        $this->db_per = $this->load->database('default', true);
        $this->db_akd = $this->load->database('db_akd', true);
        //$this->db_rad = $this->load->database('db_rad', true);
        $this->load->helper('smart_helper');
        $this->load->model('Personalia_model');
        $this->load->model('Option_model');
        $this->user_id = $this->session->userdata('user_id');

        $is_kepala = $this->db_per->where('kepala', $this->user_id)->get('per_master_unit_kerja')->row();
        if ($is_kepala) {
            $this->is_kepala = TRUE;
        }
        $this->npk = $this->session->userdata('npk');
        $this->jabatan = $this->session->userdata('jabatan');

        $this->is_rektor = $this->db->where('fk_id_jabatan', 93)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->get('per_info_jabatan')->row();
        $this->is_warek1 = $this->db->where('fk_id_jabatan', 94)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->get('per_info_jabatan')->row();
        $this->is_warek2 = $this->db->where('fk_id_jabatan', 88)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->get('per_info_jabatan')->row();
        $this->is_warek3 = $this->db->where('fk_id_jabatan', 89)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->get('per_info_jabatan')->row();
        $this->is_kabaak = $this->db->where('fk_id_jabatan', 10)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->get('per_info_jabatan')->row();
        $this->is_kabauk = $this->db->where('fk_id_jabatan', 10)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->get('per_info_jabatan')->row();
        $this->is_katipd = $this->db->where('fk_id_jabatan', 7)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                              ->where('fk_id_unit_kerja', 8)
                              ->get('per_info_jabatan')->row();
        $this->is_kaprodi= $this->db->where('fk_id_jabatan', 24)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                          ->get('per_info_jabatan')->row();
        $this->is_pjsd= $this->db->where('fk_id_jabatan', 2)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                           ->get('per_info_jabatan')->row();
        $this->is_pjswd= $this->db->where('fk_id_jabatan', 46)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                           ->get('per_info_jabatan')->row();
        $this->is_dekan= $this->db->where('fk_id_jabatan', 5)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                           ->get('per_info_jabatan')->row();
        $this->is_wadek= $this->db->where('fk_id_jabatan', 87)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                           ->get('per_info_jabatan')->row();
        $this->is_kabak_ak   = $this->db->where("(ket = 1 AND fk_id_personal = '".$this->user_id."' AND fk_id_unit_kerja = 7 AND fk_id_jabatan = 14) OR
                                                 (ket = 1 AND fk_id_personal = '".$this->user_id."' AND fk_id_unit_kerja = 7 AND fk_id_jabatan = 25) OR
                                                 (ket = 1 AND fk_id_personal = '".$this->user_id."' AND fk_id_unit_kerja = 29 AND fk_id_jabatan = 86)")
                                            ->get('per_info_jabatan')->row();
        $this->is_baak   = $this->db->where('fk_id_jabatan', 86)->where('ket', 1)->where('fk_id_personal', $this->user_id)
                          ->where('fk_id_unit_kerja', 7)
                          ->get('per_info_jabatan')->row();
        
        $this->is_ktu     = $this->db_per->where("NA = 'N' AND ket = 1 AND fk_id_personal ='$this->user_id'
                                                 AND fk_id_unit_kerja != 7 AND
                                                (fk_id_jabatan = 14 OR fk_id_jabatan = 25)")
                                        ->get('per_info_jabatan')->row();
        $this->is_tu     = $this->db_per->join('per_master_unit_kerja', 'per_master_unit_kerja.id = per_info_jabatan.fk_id_unit_kerja')
                                        ->where("per_info_jabatan.NA = 'N' AND per_master_unit_kerja.status = 'Fakultas' AND per_info_jabatan.ket = 1 AND per_info_jabatan.fk_id_personal ='$this->user_id'
                                                 AND (fk_id_jabatan = 91 OR fk_id_jabatan = 86)")
                                        ->get('per_info_jabatan')->row();
        $this->is_klp2m     = $this->db_per->where("NA = 'N' AND ket = 1 AND fk_id_personal ='$this->user_id'
                                                 AND fk_id_unit_kerja = 4 AND fk_id_jabatan = 47")
                                        ->get('per_info_jabatan')->row();
        $this->is_dosen  = $this->db_per->where('NA', 'N')->where('id', $this->user_id)->where('status_karyawan = "Dosen" OR status_karyawan = "Dosen LB"')
                                    ->get('per_info_personal')->row();

        

        $this->user_id      = $this->session->userdata('user_id');
        $this->npk          = $this->session->userdata('npk');
        $this->jabatan      = $this->session->userdata('jabatan');
        $this->unit_kerja   = $this->session->userdata('unit_kerja');
        $this->homebase              = $this->session->userdata('homebase');

        if ($this->jabatan==8){
            $_SESSION['prodie']=".".$this->homebase.".";
            $_SESSION['menu_keu']=FALSE;
            $_SESSION['menu']=TRUE;
        }else if ($this->jabatan==24 || $this->jabatan==45){
            $_SESSION['prodie']=".".$this->homebase.".";
            $_SESSION['menu']=TRUE;
            $_SESSION['menu_keu']=TRUE;
        }else if ($this->jabatan==93 || ($this->jabatan==7 && $this->unit_kerja == 8) || $this->jabatan==10 || ($this->jabatan==86 && $this->unit_kerja == 8) || $this->jabatan==92 || $this->jabatan==88){
            $_SESSION['prodie'] = $this->Prodi();
            $_SESSION['menu']=TRUE;
            $_SESSION['menu_keu']=TRUE;
        }else if ($this->jabatan==5 || $this->jabatan==87 || $this->jabatan==90 || $this->jabatan==91 || $this->jabatan==46 || $this->jabatan==86 || $this->jabatan==14 || $this->jabatan==25){
            @$fk=$this->db->where('per_info_personal.id',$this->user_id)
                        ->where('per_master_unit_kerja.kode !=','')
                        ->join('per_master_unit_kerja','per_master_unit_kerja.id=per_info_jabatan.fk_id_unit_kerja')
                        ->join('per_info_personal','per_info_personal.id=per_info_jabatan.fk_id_personal')
                        ->select('kode')
                        ->get('per_info_jabatan')->row()->kode;
            if($fk)
            {
                $_SESSION['prodie'] = $this->Prodi_Fakultas($fk);
                $_SESSION['menu']=TRUE;
                $_SESSION['menu_keu']=TRUE;
            }else{
                $_SESSION['menu_keu']=FALSE;
                $_SESSION['menu']=FALSE;
            }
        }else{
            $_SESSION['menu_keu']=FALSE;
            $_SESSION['menu']=FALSE;
        }

        if (!$this->user_id){
          redirect('auth/login/user_dashboard', 'refresh');
        }
    }

    function Prodi_Fakultas($fakultas)
    {
        $Q = $this->db_akd->query("SELECT ProdiID FROM  prodi  WHERE  FakultasID='$fakultas'");
        $prodi='';
        foreach ($Q ->result_array() as $r)
        {
            $prodi.=".".$r['ProdiID'].".";
        }
        return $prodi;
    }

    function Prodi()
    {
        $Q = $this->db_akd->query("SELECT ProdiID FROM  prodi");
        $prodi='';
        foreach ($Q ->result_array() as $r)
        {
            $prodi.=".".$r['ProdiID'].".";
        }
        return $prodi;
    }

}

/* End of file PER_Peg_Controller.php */
/* Location: ./application/libraries/PER_Peg_Controller.php */