<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PER_Adm_Controller extends MY_Controller {

	function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('default', true);
        $this->load->helper('smart_helper');
        $this->load->model('Personalia_model');
        $this->load->model('Option_model');
        $this->user_id = $this->session->userdata('user_id');
        $this->npk = $this->session->userdata('npk');
        $this->jabatan = $this->session->userdata('jabatan');
        $this->unit_kerja = $this->session->userdata('unit_kerja');
        if ($this->jabatan!=3){
			redirect('auth/login/data_dashboard', 'refresh');
		}
    }

}

/* End of file MY_Controller.php */
/* Location: ./application/libraries/MY_Controller.php */