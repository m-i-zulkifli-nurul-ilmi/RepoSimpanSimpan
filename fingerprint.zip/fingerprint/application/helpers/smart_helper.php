<?php 
    function get_time_difference($time1, $time2) {
        $start_date = new DateTime($time1);
        $since_start = $start_date->diff(new DateTime($time2));
        $data['total_hari'] = $since_start->days.' days total<br>';
        $data['tahun'] = $since_start->y;
        $data['bulan'] = $since_start->m;
        $data['hari'] = $since_start->d;
        $data['jam'] = $since_start->h;
        $data['menit'] = $since_start->i;
        $data['detik'] = $since_start->s;
        $data['menit'] = $since_start->days * 24 * 60;
        $data['menit'] += $since_start->h * 60;
        $data['menit'] += $since_start->i;
        
        return $data;
    }

    function catat_log($id,$var)
    {
        $tgl=gmdate("Y-m-d",time()+60*60*7);
        $_logfilename = APPPATH  . "logs/Queries.".$tgl.".log"; //nama log: Queries.23-02-2017.log, di folder applications/logs
        
        // jika file log belum ada, buat dulu
        if(!file_exists($_logfilename)){
            $fp = fopen($_logfilename, "a");
            @fputs($fp, "/* File log SMART [".$tgl."]*/\n");
        }else{
             $fp = fopen($_logfilename, "a");
        }
         
        // catat lognya
        $waktu = "\n[".gmdate("H:i:s",time()+60*60*7)."]";
        $ip="[".$_SERVER['REMOTE_ADDR']."]";
        $id="[".$id."]";
        $url="[".$_SERVER['REQUEST_URI']."]";
        @fputs($fp,$waktu." - ".$ip." - ".$id." - ".$url." - ".$var."\n");
    }

    function to_currency($number)
    {
        if($number >= 0)
        {
            return 'Rp. '.number_format($number, 0, ',', '.');
        }
        else
        {
            return 'Rp. '.number_format(abs($number), 0, ',', '.');
        }
    }

    function bilangan($number)
    {
        if($number > 0)
        {
            return number_format($number, 0, ',', '.');
        }
        else
        {
            return '0';
        }
    }
    function rupiah($number)
    {
        if ($number==0) return '-';
        return to_currency($number);
    }
    function umur($usia) {     
        $year = date("Y", strtotime($usia));
        $month = date("m", strtotime($usia));
        $day = date("d", strtotime($usia));
        $birthday = strtotime($year.'-'.$month.'-'.$day);
        $current_time = time();
        $curr['month'] = date('n', $current_time);
        $curr['lastmonth'] = $curr['month'] - 1;
        $curr['year'] = date('Y', $current_time);
        $curr['lastyear'] = $curr['year'] - 1;
        $curr['day'] = date('j', $current_time);

        $diff = $current_time - $birthday;
        $age['years'] = intval($diff/31556926);
        $diff = $diff - (31556926 * $age['years']);
        if($curr['month'] > $month) {
            $age['months'] = $curr['month'] - $month;
        if($curr['day'] < $day) {
            $age['months']--;
            $month_temp = strtotime($curr['year'].'-'.$curr['lastmonth'].'-'.$day);
        } else {
            $month_temp = strtotime($curr['year'].'-'.$curr['month'].'-'.$day);
        }
            $diff = $current_time - $month_temp;
        } elseif($curr['month'] == $month) {
        if($curr['day'] >= $day) {
            $age['months'] = 0;
        } else {
            $age['months'] = 11;
            $month_temp = strtotime($curr['year'].'-'.$curr['lastmonth'].'-'.$day);
            $diff = $current_time - $month_temp;
        }
        } else {
            $age['months'] = $curr['month'] - $month + 12;
        if($curr['day'] < $day) {
            $age['months']--;
            $month_temp = strtotime($curr['year'].'-'.$curr['lastmonth'].'-'.$day);
        } else {
            $month_temp = strtotime($curr['year'].'-'.$curr['month'].'-'.$day);
        }
            $diff = $current_time - $month_temp;
        }

        $age['days'] = intval($diff/86400);
        $diff = $diff - (86400 * $age['days']);

        $age['hours'] = intval($diff/3600);
        $diff = $diff - (3600 * $age['hours']);

        $age['minutes'] = intval($diff/60);
        $diff = $diff - (60 * $age['minutes']);

        $age['seconds'] = $diff;

        return $age['years'];

    }

    function to_pdf($html, $filename='', $stream=TRUE) 
    {
        require_once(APPPATH."libraries/dompdf/dompdf_config.inc.php");
        
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
        $dompdf->render();
        if ($stream) {
            $dompdf->stream($filename.".pdf");
        } else {
            return $dompdf->output();
        }
    }

    function cetak_report($html,$out)
    {
        if ($out=='pdf')
            to_pdf($html,'Report'.rand(100,1000));
        else
            echo $html;

    }

    function tgl_sql($date){
        $exp = explode('/',$date);
        if(count($exp) == 3) {
            $date = $exp[2].'-'.$exp[1].'-'.$exp[0];
        }
        return $date;
    }

    function nama_hari($i)
    {
        $bulan = array(
            'Minggu','Senin','Selasa','Rabu','Kamis','Jum\'at','Sabtu','Minggu'
        );

        return $bulan[$i];
    }

    function nama_bulan($i)
    {
        $bulan = array(
            'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'
        );

        return $bulan[$i-1];
    }

    function bulan_romawi($i)
    {
        $bulan = array(
            'I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'
        );

        return $bulan[$i-1];
    }

    function tanggal($tanggal)
    {
        if ($tanggal && $tanggal != '0000-00-00') {
            return date('d',strtotime($tanggal)).'  '.nama_bulan(date('m',strtotime($tanggal))).' '.date('Y',strtotime($tanggal));
        } else {
            return '-';
        }
                    
    }

    function t($v)
    {
        if ((int)$v==0)
            return "-";
        return (int)$v;

    }

    function tahun_akademik($str){
        $r = substr($str, -1);
        $t = substr($str,0, -1);
        if($r==1)
            return $t.' GANJIL';
        else
            return $t.' GENAP';

    }

    function beda_tanggal($date1,$date2) {
        $now = time(); // or your date as well
        $your_date = strtotime($date2);
        $datediff = strtotime($date1) - $your_date;

        return 1 + floor($datediff / (60 * 60 * 24));
    }

    function beda_bulan($date1,$date2) {
        $timeStart = strtotime($date1);
        $timeEnd = strtotime($date2);
        $numBulan = (date("Y",$timeEnd)-date("Y",$timeStart))*12;
        $numBulan += date("m",$timeEnd)-date("m",$timeStart);
        return $numBulan;
    }

    function jumlah_minggu($date1,$date2) {
        $start = new DateTime($date1);
        $end = new DateTime($date2);
        $days = $start->diff($end, true)->days;

        $sundays = intval($days / 7) + ($start->format('N') + $days % 7 >= 7);

        return $sundays;
    }

    function opt_bulan(){
        $bulan = array(
            ''  => 'Pilih Bulan',
            1  => 'Januari',
            2  => 'Februari',
            3  => 'Maret',
            4  => 'April',
            5  => 'Mei',
            6  => 'Juni',
            7  => 'Juli',
            8  => 'Agustus',
            9  => 'September',
            10 => 'Oktober',
            11 => 'November',
            12 => 'Desember'
        );
        return $bulan;
    }

    function opt_tahun(){
        $opt_tahun[''] = 'Pilih Tahun';
        for ($i=1990; $i < date('Y') + 1; $i++) {
            $opt_tahun[$i] = $i;
        }
        return $opt_tahun;
    }

    function NamaTahun($tahun, $prodi='') {
        $arr = array('1'=>'Ganjil', '2'=>'Genap', '1p'=>'Pendek Ganjil', '2p'=>'Pendek Genap');
        $_tahun = substr($tahun, 0, 4)+0;
        $_tahun1 = $_tahun + 1;
        $_smt = substr($tahun, 4, 4);
        $NamaSesi = (empty($prodi))? '' : $this->db->where('ProdiID', $prodi)->get('prodi')->row()->NamaSesi. ' '; 
        return $NamaSesi .$arr[$_smt] . " $_tahun/$_tahun1";
    }

    function tanggal_waktu($tanggal)
    {
    return date('d',strtotime($tanggal)).'  '.nama_bulan(date('m',strtotime($tanggal))).' '.date('Y',strtotime($tanggal)).' - '.date('H',strtotime($tanggal)).':'.date('i',strtotime($tanggal)).':'.date('s',strtotime($tanggal));
                    
    }