<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config["mailtype"] = "html";
$config["protocol"] = "sendmail";
$config["smtp_host"] = "ssl://smtp.googlemail.com";
$config["smtp_user"] = "heruprambadi@gmail.com";
$config["smtp_pass"] = "1213141516171819heru";
$config["smtp_port"] = 465;
$config["crlf"] = "\r\n";
$config["newline"] = "\r\n";