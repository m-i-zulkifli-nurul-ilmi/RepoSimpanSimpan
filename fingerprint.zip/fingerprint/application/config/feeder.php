<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Ion Auth
*
* Version: 2.5.2
*
* Author: Ben Edmunds
*		  ben.edmunds@gmail.com
*         @benedmunds
*
* Added Awesomeness: Phil Sturgeon*/

////FEEDER CONFIG///////
$config['username'] = '101018';
$config['password'] = 'b44kumr1';
$config['url'] = 'localhost';
$config['port'] = '8082';
$config['kode_pt'] = '101018';
////FEEDER CONFIG///////

/* End of file feeder.php */
/* Location: ./application/config/feeder.php */
