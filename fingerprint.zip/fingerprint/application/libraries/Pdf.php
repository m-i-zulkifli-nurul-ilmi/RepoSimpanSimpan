<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require('fpdf.php');
class Pdf extends FPDF{

    /*function __construct($orientation='L', $unit='mm', $size='A4')
    {
        parent::__construct($orientation,$unit,$size);
    }*/

    function Header(){    
        $mrg = 35;
        $pjg = 140;
        
        $logo = (file_exists("../modules/akademik/assets/image/logo.gif"))? "../modules/akademik/assets/image/logo.gif" : ((file_exists("modules/akademik/assets/image/logo.gif")) ? "modules/akademik/assets/image/logo.gif"  : "application/modules/akademik/assets/image/logo.gif");
        $this->Image($logo, 20, 1, 23);
        $this->SetFont("Helvetica", '', 11);
        $this->Cell($mrg);
        $this->Cell($pjg, 5, "SISTEM INFORMASI AKADEMIK", 0, 1, 'C');
        $this->Cell($mrg);
        $this->Cell($pjg, 5, "UNIVERSITAS MUHAMMADIYAH RIAU", 0, 1, 'C');
        
        $this->SetFont("Helvetica", 'I', 9);
        $this->Cell($mrg);
        $this->Cell($pjg, 5,
          "Jl. KH. Ahmad Dahlan 88, Sukajadi, Pekanbaru", 0, 1, 'C');
        $this->Cell(8);
        $this->Cell(180, 0, "", 1, 1);
        $this->Ln(2);
    }   

    function Header2(){    
        $mrg = 35;
        $pjg = 140;
        
        $logo = (file_exists("../modules/akademik/assets/image/logo.gif"))? "../modules/akademik/assets/image/logo.gif" : ((file_exists("modules/akademik/assets/image/logo.gif")) ? "modules/akademik/assets/image/logo.gif"  : "application/modules/akademik/assets/image/logo.gif");
        //$this->Image($logo, 20, 1, 23);
        $this->SetFont("Helvetica", '', 11);
        $this->Cell($mrg);
        $this->Cell($pjg, 5, "SISTEM INFORMASI AKADEMIK", 0, 1, 'C');
        $this->Cell($mrg);
        $this->Cell($pjg, 5, "UNIVERSITAS MUHAMMADIYAH RIAU", 0, 1, 'C');
        
        $this->SetFont("Helvetica", 'I', 9);
        $this->Cell($mrg);
        $this->Cell($pjg, 5,
          "Jl. KH. Ahmad Dahlan 88, Sukajadi, Pekanbaru", 0, 1, 'C');
        $this->Cell(8);
        $this->Cell(180, 0, "", 1, 1);
        $this->Ln(2);
    }                           


}