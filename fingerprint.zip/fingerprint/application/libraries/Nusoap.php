<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Nusoap{
	function nusoap(){
		require_once('nusoap/nusoap'.EXT);
	}
}