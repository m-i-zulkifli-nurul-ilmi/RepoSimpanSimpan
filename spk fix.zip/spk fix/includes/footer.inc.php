	<hr>
	<footer class="text-center">Copyright &copy; 2017 UKM Kesenian STMIK Akakom Yogyakarta</footer>
	</div>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="assets/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.toastmessage.js"></script>
    <script type="text/javascript" src="assets/js/parsley.min.js"></script>
		<script type="text/javascript" src="assets/js/app.js"></script>
  </body>
</html>
